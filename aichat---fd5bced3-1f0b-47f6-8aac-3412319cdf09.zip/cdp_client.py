import websocket
import json
import requests
import time
import logging

logger = logging.getLogger('deepseek-proxy')

class BaseCDP:
    """
    CDP 客户端基类，封装所有浏览器交互逻辑。
    子类只需定义模型特定的选择器和标题关键字。
    """
    MODEL_TITLE_KEYWORD = ""
    INPUT_SELECTORS = [
        'textarea',
        '[contenteditable="true"]',
        '[role="textbox"]'
    ]
    STOP_BUTTON_SELECTOR = '[aria-label="停止生成"]'
    SEND_BUTTON_SELECTOR = ''            # 发送按钮选择器，为空时不使用点击发送
    LOADING_SELECTORS = [
        '.ds-loading', '.loading-spinner', '[class*="loading"]', '.animate-spin'
    ]
    ASSISTANT_MSG_SELECTORS = [
        '.ds-markdown', '.assistant-message', '[class*="assistant"]',
        '[class*="reply"]', '.message-content'
    ]
    NEW_CHAT_BUTTON_SELECTORS = [
        'button:has(span:contains("新对话"))',
        '[data-testid="new-chat"]',
        '.new-chat-btn',
        '[aria-label="新对话"]',
        '[aria-label="New Chat"]',
        '.sidebar-new-chat'
    ]

    def __init__(self, ws_url=None):
        self.ws = None
        self.msg_id = 0
        self.ws_url = ws_url

    # ---------- 连接管理 ----------
    def get_debug_url(self):
        try:
            resp = requests.get('http://localhost:9222/json', timeout=3)
            tabs = resp.json()
            for tab in tabs:
                if self.MODEL_TITLE_KEYWORD in tab.get('title', ''):
                    return tab['webSocketDebuggerUrl']
        except:
            logger.warning("无法连接 Chrome 调试端口")
        return None

    def connect(self, ws_url=None):
        url = ws_url or self.ws_url or self.get_debug_url()
        if not url:
            return False
        self.ws = websocket.create_connection(url, timeout=10)
        self.ws_url = url
        return True

    def send_cmd(self, method, params=None):
        self.msg_id += 1
        cmd = {"id": self.msg_id, "method": method, "params": params or {}}
        self.ws.send(json.dumps(cmd))
        return self.msg_id

    def get_reply(self, msg_id, timeout=10):
        self.ws.settimeout(timeout)
        while True:
            try:
                resp = json.loads(self.ws.recv())
                if resp.get('id') == msg_id:
                    return resp
            except websocket.WebSocketTimeoutException:
                return None
            except Exception as e:
                logger.debug(f"CDP recv error: {e}")
                return None

    def evaluate(self, js, timeout=10):
        msg_id = self.send_cmd("Runtime.evaluate", {
            "expression": js,
            "returnByValue": True
        })
        resp = self.get_reply(msg_id, timeout)
        if resp and 'result' in resp:
            result = resp['result'].get('result', {})
            if 'value' in result:
                return result['value']
            if result.get('type') == 'object' and 'description' in result:
                return result['description']
        return None

    # ---------- 页面状态检测 ----------
    def _get_page_state(self):
        js = f"""
        (function() {{
            const selectors = {json.dumps(self.INPUT_SELECTORS)};
            let inputEl = null;
            for (const sel of selectors) {{
                inputEl = document.querySelector(sel);
                if (inputEl && inputEl.offsetParent !== null) break;
                inputEl = null;
            }}
            // Fallback：使用当前聚焦的元素
            if (!inputEl) {{
                const activeEl = document.activeElement;
                if (activeEl && (activeEl.isContentEditable || activeEl.tagName === 'TEXTAREA' || activeEl.tagName === 'INPUT')) {{
                    inputEl = activeEl;
                }}
            }}
            let inputInfo = {{ found: false, content: '', disabled: false, readonly: false }};
            if (inputEl) {{
                inputInfo.found = true;
                if (inputEl.tagName === 'TEXTAREA' || inputEl.tagName === 'INPUT') {{
                    inputInfo.content = inputEl.value || '';
                }} else {{
                    inputInfo.content = inputEl.textContent || '';
                }}
                inputInfo.disabled = inputEl.disabled || false;
                inputInfo.readonly = inputEl.readOnly || false;
                if (inputEl.getAttribute('contenteditable') === 'false') {{
                    inputInfo.disabled = true;
                }}
            }}
            const stopBtn = document.querySelector('{self.STOP_BUTTON_SELECTOR}');
            const isGenerating = stopBtn && stopBtn.offsetParent !== null;
            let hasLoading = false;
            const loadingEls = document.querySelectorAll({json.dumps(self.LOADING_SELECTORS)}.join(','));
            for (const el of loadingEls) {{
                if (el.offsetParent !== null) {{ hasLoading = true; break; }}
            }}
            const assistantMsgs = document.querySelectorAll({json.dumps(self.ASSISTANT_MSG_SELECTORS)}.join(','));
            let assistantMsgCount = assistantMsgs.length;
            return JSON.stringify({{
                input: inputInfo,
                isGenerating: isGenerating,
                hasLoading: hasLoading,
                assistantMsgCount: assistantMsgCount
            }});
        }})()
        """
        try:
            result = self.evaluate(js)
            if result and isinstance(result, str):
                return json.loads(result)
        except:
            pass
        return None

    def is_generating(self):
        js = f"""
        (function() {{
            const stopBtn = document.querySelector('{self.STOP_BUTTON_SELECTOR}');
            if (stopBtn && stopBtn.offsetParent !== null) return true;
            const loading = document.querySelectorAll({json.dumps(self.LOADING_SELECTORS)}.join(','));
            for (const el of loading) {{
                if (el.offsetParent !== null) return true;
            }}
            return false;
        }})()
        """
        res = self.evaluate(js)
        return res is True or res == 'true' or res == 'True'

    def _is_input_ready(self):
        state = self._get_page_state()
        if not state:
            return False, "无法获取页面状态"
        if state.get('isGenerating'):
            return False, "正在生成回复"
        if state.get('hasLoading'):
            return False, "页面加载中"
        inp = state.get('input', {})
        if not inp.get('found'):
            return False, "未找到输入框"
        if inp.get('disabled') or inp.get('readonly'):
            return False, "输入框被禁用或只读"
        return True, "就绪"

    def _wait_for_input_ready(self, timeout=30):
        start = time.time()
        last_state = ""
        while time.time() - start < timeout:
            ready, desc = self._is_input_ready()
            if ready:
                return True, desc
            if desc != last_state:
                logger.debug(f"等待输入框就绪: {desc}")
                last_state = desc
            time.sleep(1.0)
        return False, f"等待超时 ({timeout}s): {last_state}"

    # ---------- 输入操作 ----------
    def set_input_text(self, text):
        """设置输入框文本，内置焦点元素 fallback"""
        js = f"""
        (function() {{
            const selectors = {json.dumps(self.INPUT_SELECTORS)};
            let input = null;
            for (const sel of selectors) {{
                input = document.querySelector(sel);
                if (input && input.offsetParent !== null) break;
                input = null;
            }}
            if (!input) {{
                // Fallback：尝试当前聚焦元素
                const activeEl = document.activeElement;
                if (activeEl && (activeEl.isContentEditable || activeEl.tagName === 'TEXTAREA' || activeEl.tagName === 'INPUT')) {{
                    input = activeEl;
                }}
            }}
            if (!input) return 'NO_INPUT';

            input.focus();
            const t = {json.dumps(text)};

            if (input.tagName === 'TEXTAREA' || input.tagName === 'INPUT') {{
                const nativeSetter = Object.getOwnPropertyDescriptor(
                    window.HTMLTextAreaElement.prototype, 'value'
                ).set;
                nativeSetter.call(input, t);
                input.dispatchEvent(new Event('input', {{ bubbles: true }}));
            }} else {{
                while (input.firstChild) {{
                    input.removeChild(input.firstChild);
                }}
                input.textContent = t;
                input.dispatchEvent(new Event('input', {{ bubbles: true }}));
            }}
            return 'OK';
        }})()
        """
        return self.evaluate(js)

    def press_enter(self):
        """模拟 Enter 键"""
        js = f"""
        (function() {{
            const input = document.querySelector('{self.INPUT_SELECTORS[0]}') || document.activeElement;
            if (!input) return 'NO_INPUT';
            const opts = {{
                key: 'Enter',
                code: 'Enter',
                keyCode: 13,
                which: 13,
                bubbles: true,
                cancelable: true,
                composed: true
            }};
            input.dispatchEvent(new KeyboardEvent('keydown', opts));
            input.dispatchEvent(new KeyboardEvent('keypress', opts));
            input.dispatchEvent(new KeyboardEvent('keyup', opts));
            return 'SENT';
        }})()
        """
        return self.evaluate(js)

    def click_send_button(self):
        """点击发送按钮（如果定义了选择器）"""
        if not self.SEND_BUTTON_SELECTOR:
            return 'NO_SELECTOR'
        js = f"""
        (function() {{
            const btn = document.querySelector('{self.SEND_BUTTON_SELECTOR}');
            if (btn && btn.offsetParent !== null) {{
                btn.click();
                return 'CLICKED';
            }}
            // 备选：查找包含发送文字或图标的按钮
            const buttons = document.querySelectorAll('button, [role="button"]');
            for (const b of buttons) {{
                const text = b.textContent || '';
                const aria = b.getAttribute('aria-label') || '';
                if (text.includes('发送') || text.includes('Send') || aria.includes('send')) {{
                    b.click();
                    return 'TEXT_CLICK';
                }}
            }}
            return 'NOT_FOUND';
        }})()
        """
        return self.evaluate(js)

    def _get_input_content(self):
        state = self._get_page_state()
        if state and state.get('input', {}).get('found'):
            return state['input'].get('content', '')
        return None

    def _get_assistant_msg_count(self):
        state = self._get_page_state()
        if state:
            return state.get('assistantMsgCount', 0)
        return 0

    # ---------- 发送与接收 ----------
    def send_and_get_reply(self, message, wait=True):
        max_retries = 3
        for attempt in range(max_retries):
            if attempt > 0:
                wait_time = 3 * attempt
                logger.info(f"重试发送 (第 {attempt + 1}/{max_retries} 次)，等待 {wait_time} 秒...")
                time.sleep(wait_time)

            ready, desc = self._wait_for_input_ready(timeout=30)
            if not ready:
                logger.error(f"输入框未就绪: {desc}")
                if attempt < max_retries - 1:
                    continue
                raise Exception(f"输入框不可用: {desc}")

            msg_count_before = self._get_assistant_msg_count()
            input_before = self._get_input_content()
            logger.debug(f"发送前: 消息数={msg_count_before}, 输入框长度={len(input_before) if input_before else 0}")

            res = self.set_input_text(message)
            if res != 'OK':
                logger.warning(f"设置输入文本失败: {res}")
                if attempt < max_retries - 1:
                    continue
                raise Exception(f"输入失败: {res}")

            time.sleep(0.5)
            input_after_set = self._get_input_content()
            if input_after_set and len(input_after_set.strip()) < 10:
                logger.warning("输入框内容为空，文本可能未正确设置")
                if attempt < max_retries - 1:
                    continue
            else:
                logger.debug(f"文本设置成功，输入框长度={len(input_after_set) if input_after_set else 0}")

            time.sleep(0.3)

            # 发送消息：先尝试 Enter，若失败则点击发送按钮
            sent = False
            res = self.press_enter()
            if res == 'SENT':
                sent = True
            else:
                logger.debug("按 Enter 未成功，尝试点击发送按钮")
                click_res = self.click_send_button()
                if click_res in ('CLICKED', 'TEXT_CLICK'):
                    sent = True

            if not sent:
                logger.warning("发送失败，既没有按 Enter 也没有找到发送按钮")
                if attempt < max_retries - 1:
                    continue
                raise Exception("发送失败：无法触发发送操作")

            time.sleep(2.0)
            is_generating_now = self.is_generating()
            input_after_send = self._get_input_content()
            msg_count_after = self._get_assistant_msg_count()
            logger.debug(f"发送后: 生成中={is_generating_now}, 输入框长度={len(input_after_send) if input_after_send else 0}, 消息数={msg_count_after}")

            sent_successfully = False
            if is_generating_now:
                logger.debug("检测到生成状态，消息已成功发出")
                sent_successfully = True
            elif input_after_send is not None and len(input_after_send.strip()) < 10:
                logger.debug("输入框已清空，消息已成功发出")
                sent_successfully = True
            elif msg_count_after > msg_count_before:
                logger.debug(f"消息数增加，消息已发出")
                sent_successfully = True
            else:
                logger.warning("无法确认消息是否成功发出")
                if input_after_send and input_before:
                    if input_after_send == input_before:
                        logger.warning("输入框内容未变化，消息可能未发出")
                        if attempt < max_retries - 1:
                            continue
                    elif len(input_after_send) < len(input_before):
                        logger.warning("输入框内容变短但未清空，状态不确定")
                if not is_generating_now and msg_count_after == msg_count_before:
                    logger.warning("不在生成状态且消息数未变，消息可能未发出")
                    if attempt < max_retries - 1:
                        continue
            logger.info("消息发送成功")
            break

        if wait:
            time.sleep(1.5)
            reply = self.wait_for_reply(timeout=60)
            all_text = self.get_all_text()
            return reply, all_text
        return None, None

    # ---------- 回复等待 ----------
    def get_last_reply(self):
        js = f"""
        (function() {{
            const selectors = {json.dumps(self.ASSISTANT_MSG_SELECTORS)};
            let all = [];
            for (const sel of selectors) {{
                const nodes = document.querySelectorAll(sel);
                if (nodes.length > 0) {{
                    all = Array.from(nodes);
                    break;
                }}
            }}
            if (all.length === 0) return '';
            const last = all[all.length - 1];
            return last.textContent || last.innerText || '';
        }})()
        """
        return self.evaluate(js)

    def get_all_text(self):
        js = f"""
        (function() {{
            const selectors = {json.dumps(self.ASSISTANT_MSG_SELECTORS)};
            let all = [];
            for (const sel of selectors) {{
                const nodes = document.querySelectorAll(sel);
                if (nodes.length > 0) {{
                    all = Array.from(nodes).map(n => n.textContent || '');
                    break;
                }}
            }}
            if (all.length === 0) {{
                const chat = document.querySelector('.chat-container, .conversation, main');
                return chat ? chat.textContent || '' : '';
            }}
            return all.join('\\n');
        }})()
        """
        return self.evaluate(js)

    def wait_until_idle(self, timeout=15):
        start = time.time()
        while time.time() - start < timeout:
            if not self.is_generating():
                return True
            time.sleep(0.5)
        return False

    def wait_for_reply(self, timeout=60):
        prev = ""
        stable_count = 0
        start = time.time()
        last_content = ""
        generation_ended = False

        while time.time() - start < timeout:
            current = self.get_last_reply()
            if current:
                last_content = current
            content_len = len(last_content)
            is_generating = self.is_generating()

            if not is_generating and not generation_ended:
                if content_len > 10:
                    logger.debug(f"生成状态结束，当前内容长度: {content_len}")
                    generation_ended = True

            if not is_generating:
                if last_content == prev and content_len > 10:
                    stable_count += 1
                    if content_len > 500:
                        needed = 2
                    elif content_len > 100:
                        needed = 3
                    else:
                        needed = 4
                    if stable_count >= needed:
                        logger.debug(f"回复完成: {content_len} 字符, 稳定 {stable_count} 次")
                        return last_content
                elif last_content != prev:
                    stable_count = 0
                    prev = last_content

            elapsed = time.time() - start
            if elapsed > timeout * 0.75 and content_len > 20 and stable_count >= 1:
                logger.debug(f"接近超时提前返回: {content_len} 字符")
                return last_content

            time.sleep(0.8)

        logger.warning(f"wait_for_reply 超时 ({timeout}s)，最后内容长度 {len(last_content)}")
        return last_content if len(last_content) > 10 else None

    # ---------- 对话管理 ----------
    def new_chat(self):
        js = f"""
        (function() {{
            const selectors = {json.dumps(self.NEW_CHAT_BUTTON_SELECTORS)};
            for (const sel of selectors) {{
                const btn = document.querySelector(sel);
                if (btn) {{ btn.click(); return 'CLICKED'; }}
            }}
            const buttons = document.querySelectorAll('button, a');
            for (const btn of buttons) {{
                if (btn.textContent.includes('新对话') || btn.textContent.includes('New Chat')) {{
                    btn.click();
                    return 'TEXT_CLICK';
                }}
            }}
            return 'NOT_FOUND';
        }})()
        """
        return self.evaluate(js)

    def upload_files(self, file_paths):
        try:
            doc_resp = self.send_cmd("DOM.getDocument")
            doc_reply = self.get_reply(doc_resp)
            if not doc_reply or 'result' not in doc_reply:
                return False
            root_id = doc_reply['result']['root']['nodeId']
            query_resp = self.send_cmd("DOM.querySelector", {
                "nodeId": root_id,
                "selector": "input[type=file]"
            })
            query_reply = self.get_reply(query_resp)
            if not query_reply or 'result' not in query_reply:
                return False
            node_id = query_reply['result'].get('nodeId')
            if not node_id or node_id == 0:
                return False
            self.send_cmd("DOM.setFileInputFiles", {
                "files": file_paths,
                "nodeId": node_id
            })
            time.sleep(0.5)
            return True
        except Exception as e:
            logger.warning(f"文件上传CDP失败: {e}")
            return False

    def wait_for_upload_complete(self, timeout=15):
        start = time.time()
        while time.time() - start < timeout:
            js = """
            (function() {
                const selectors = [
                    '.upload-item', '.attached-file', '.file-item',
                    '[class*="attachment"]', '[class*="upload"]'
                ];
                for (let sel of selectors) {
                    let el = document.querySelector(sel);
                    if (el && el.offsetParent !== null) return true;
                }
                return false;
            })()
            """
            if self.evaluate(js):
                return True
            time.sleep(0.5)
        return False

    def close(self):
        if self.ws:
            self.ws.close()


# ============================================================
#  具体模型实现
# ============================================================

class DeepSeekCDP(BaseCDP):
    MODEL_TITLE_KEYWORD = "DeepSeek"
    INPUT_SELECTORS = [
        'textarea',
        '[contenteditable="true"]',
        '[role="textbox"]',
        '#chat-input',
        '.input-box',
        '.chat-input',
        '.ds-input',
        'div[contenteditable="true"]'
    ]
    STOP_BUTTON_SELECTOR = '[aria-label="停止生成"]'
    LOADING_SELECTORS = [
        '.ds-loading', '.loading-spinner', '[class*="loading"]', '.animate-spin'
    ]
    ASSISTANT_MSG_SELECTORS = [
        '.ds-markdown', '.assistant-message', '[class*="assistant"]',
        '[class*="reply"]', '.message-content', '.prose', '.markdown', '.chat-message'
    ]
    # DeepSeek 可能也支持 Enter 发送，不需要发送按钮


class QwenCDP(BaseCDP):
    """通义千问（Qwen）—— 适配 2026 年新版 Slate 编辑器架构"""
    
    MODEL_TITLE_KEYWORD = "通义千问"

    # 核心变更：新版千问使用的是 div[contenteditable] 而不是 textarea
    # 根据你提供的 HTML，最精准的选择器是这个
    INPUT_SELECTORS = [
        # 1. 精准匹配你提供的 HTML 结构（最高优先级）
        'div[contenteditable="true"][data-slate-editor="true"]',
        
        # 2. 备用通用选择器
        '[data-testid="chat-input-content-measure"] [contenteditable="true"]',
        '.qwen-chat-input div[contenteditable="true"]',
        
        # 3. 兜底方案（虽然在新版里可能不存在 textarea 了）
        'textarea',
    ]

    # 发送按钮：根据你提供的 HTML，发送按钮的 aria-label 是 "发送消息"
    SEND_BUTTON_SELECTOR = """
        button[aria-label="发送消息"],
        [data-icon-type="qwpcicon-sendChat"],
        button:has(svg use[href*="sendChat"]),
        .send-button
    """.replace("\n", "").strip()

    # --- 以下是关键修复：针对 Slate.js 编辑器的特殊输入方法 ---

    def set_input_text(self, text):
        """
        重写输入方法。
        由于新版千问使用的是 Slate.js (div[contenteditable])，
        传统的 .value = text 可能无效，必须触发 React/Slate 的事件。
        """
        input_element = self.find_element(self.INPUT_SELECTORS)
        if not input_element:
            return False

        try:
            # 方法 1：尝试直接设置 innerHTML（对于 Slate 最有效）
            # Slate 编辑器通常监听 DOM 变化，设置 innerHTML 能强制更新视图
            self.driver.execute_script("""
                const element = arguments[0];
                element.innerHTML = '<p><span>' + arguments[1].replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</span></p>';
                // 手动触发 input 事件，通知 React 状态更新
                const event = new Event('input', { bubbles: true });
                element.dispatchEvent(event);
            """, input_element, text)
            
            return True
            
        except Exception as e:
            print(f"JS 输入失败: {e}")
            # 方法 2：如果 JS 失败，尝试传统的清空+发送键（作为保底）
            try:
                input_element.clear()
                input_element.send_keys(text)
                return True
            except:
                return False

    # --- 辅助调试方法 ---
    
    def debug_input_state(self):
        """
        调试用：检查输入框当前的状态
        你可以运行这个方法来看看代码是否找到了正确的元素
        """
        for selector in self.INPUT_SELECTORS:
            elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
            print(f"选择器: {selector} -> 找到 {len(elements)} 个元素")
            for i, el in enumerate(elements):
                print(f"  元素 {i}: 文本长度={len(el.text)}, innerHTML 长度={len(el.get_attribute('innerHTML') or '')}, 标签名={el.tag_name}")
    
class BaichuanCDP(BaseCDP):
    """百川大模型（百小应）"""
    MODEL_TITLE_KEYWORD = "百小应"
    INPUT_SELECTORS = [
        'textarea',
        '[contenteditable="true"]',
        '.chat-input',
        '.input-box',
        '.baichuan-input'
    ]
    STOP_BUTTON_SELECTOR = '[aria-label="停止生成"], button:has(svg)'
    LOADING_SELECTORS = [
        '.loading', '.spinner', '[class*="loading"]', '.typing'
    ]
    ASSISTANT_MSG_SELECTORS = [
        '.assistant-message', '.message-content', '.baichuan-msg', '.reply'
    ]


class ZhipuCDP(BaseCDP):
    """智谱清言"""
    MODEL_TITLE_KEYWORD = "智谱清言"
    INPUT_SELECTORS = [
        'textarea',
        '[contenteditable="true"]',
        '.chat-input',
        '.input-box',
        '.zhipu-input'
    ]
    STOP_BUTTON_SELECTOR = '[aria-label="停止生成"]'
    LOADING_SELECTORS = ['.loading', '.spinner', '[class*="loading"]']
    ASSISTANT_MSG_SELECTORS = [
        '.assistant-message', '.message-content', '.chat-message', '.reply'
    ]


class ErnieCDP(BaseCDP):
    """文心一言"""
    MODEL_TITLE_KEYWORD = "文心一言"
    INPUT_SELECTORS = [
        'textarea',
        '[contenteditable="true"]',
        '.yiyan-input',
        '.chat-input',
        '.input-box'
    ]
    STOP_BUTTON_SELECTOR = '[aria-label="停止"]'
    LOADING_SELECTORS = ['.loading', '.spinner']
    ASSISTANT_MSG_SELECTORS = [
        '.assistant-message', '.message-content', '.chat-message'
    ]


class KimiCDP(BaseCDP):
    """Moonshot Kimi"""
    MODEL_TITLE_KEYWORD = "Kimi"
    INPUT_SELECTORS = [
        'textarea',
        '[contenteditable="true"]',
        '.chat-input',
        '.kimi-input'
    ]
    STOP_BUTTON_SELECTOR = '[aria-label="停止生成"]'
    LOADING_SELECTORS = ['.loading', '.typing-dots']
    ASSISTANT_MSG_SELECTORS = [
        '.assistant-message', '.message-content', '.kimi-msg'
    ]
